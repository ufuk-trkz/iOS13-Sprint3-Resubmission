import UIKit
import Foundation

// Create a function that takes two numbers as arguments and return their sum.
// Example: addition(3, 2) ➞ 5
// Don't forget to return the result.

func sum(a: Int, b: Int) -> Int {
    
   let z = a + b
    
    print(z)
    return z
}

sum(a: 5, b: 3)

