//
//  MyMoviesTableViewCell.swift
//  MyMovies
//
//  Created by Ufuk Türközü on 31.01.20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import UIKit

class MyMoviesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var seenButton: UIButton!
    @IBAction func seenTapped(_ sender: Any) {
        toggleHasWatched()
    }
    
    var movieController = MovieController()
    
    var movie: Movie? {
        didSet {
            updateViews()
        }
    }
    
    func updateViews() {
        guard let movie = movie else { return }
        movieTitle.text = movie.title
    }
    
    func toggleHasWatched() {
        if seenButton.currentTitle == "unseen" {
            seenButton.setTitle("seen", for: .normal)
            self.movie?.hasWatched = true
        } else {
            seenButton.setTitle("unseen", for: .normal)
            self.movie?.hasWatched = false
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
