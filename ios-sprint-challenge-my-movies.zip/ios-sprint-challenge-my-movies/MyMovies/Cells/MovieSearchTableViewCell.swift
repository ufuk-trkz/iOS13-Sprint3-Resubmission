//
//  MovieSearchTableViewCell.swift
//  MyMovies
//
//  Created by Ufuk Türközü on 31.01.20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import UIKit

class MovieSearchTableViewCell: UITableViewCell {
    
    var movieController = MovieController()
    
    var movie: Movie? {
        didSet {
            updateViews()
        }
    }
    
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var addButton: UIButton!
    @IBAction func addTapped(_ sender: Any) {
        toggleIsAdded()
        guard let admovie = movie else { return }
        var addedMovie = movieController.searchedMovies
        movieController.put(movie: admovie)
        movieController.updateMovie(with: addedMovie)
    }
    
    func updateViews() {
        guard let movie = movie else { return }
        movieTitle.text = movie.title
    }
    
    func toggleIsAdded() {
        if addButton.currentTitle == "Add" {
            addButton.setTitle("Remove", for: .normal)
        } else {
            addButton.setTitle("Add", for: .normal)
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
