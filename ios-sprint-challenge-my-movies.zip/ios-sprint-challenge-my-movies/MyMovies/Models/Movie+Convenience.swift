//
//  Movie+Convenience.swift
//  MyMovies
//
//  Created by Ufuk Türközü on 31.01.20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation
import CoreData

extension Movie {
    
    var movieRepresentation: MovieRepresentation? {
        guard let title = title, let identifier = identifier else { return nil }
        return MovieRepresentation(title: title, identifier: identifier, hasWatched: hasWatched)
    }
    
    convenience init(title: String,
                     identifier: UUID = UUID(),
                     hasWatched: Bool,
                     context: NSManagedObjectContext = CoreDataStack.share.mainContext) {
        
        self.init(context: context)
        self.title = title
        self.identifier = identifier
        self.hasWatched = hasWatched
    }
    
    @discardableResult convenience init?(movieRepresentation: MovieRepresentation, context: NSManagedObjectContext) {
        
        self.init(title: movieRepresentation.title,
                  identifier: movieRepresentation.identifier ?? UUID(),
                  hasWatched: movieRepresentation.hasWatched ?? false,
                  context: context)
    
    }
    
}
