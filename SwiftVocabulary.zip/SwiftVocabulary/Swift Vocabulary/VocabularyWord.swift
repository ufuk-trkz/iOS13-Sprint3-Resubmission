//
//  VocabularyWord.swift
//  Swift Vocabulary
//
//  Created by Ufuk Türközü on 09.12.19.
//  Copyright © 2019 Ufuk Türközü. All rights reserved.
//

import Foundation

struct VocabularyWord {
   
    var word: String
    var definition: String

}
