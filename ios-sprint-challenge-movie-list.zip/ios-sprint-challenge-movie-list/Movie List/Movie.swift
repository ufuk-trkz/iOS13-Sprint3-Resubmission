//
//  Movie.swift
//  Movie List
//
//  Created by Ufuk Türközü on 13.12.19.
//  Copyright © 2019 Lambda School. All rights reserved.
//

import Foundation

struct Movie {
    
    let moviesName: String
    let seen: Bool = false

}
