//
//  VocabularyController.swift
//  Swift Vocabulary
//
//  Created by Ufuk Türközü on 09.12.19.
//  Copyright © 2019 Ufuk Türközü. All rights reserved.
//

import Foundation

class VocabularyController {
    
    init() {
        
        let word1 = VocabularyWord(word: "Variable", definition: "A named value used to store information.")
        let word2 = VocabularyWord(word: "Constant", definition: "...")
        let word3 = VocabularyWord(word: "Function", definition: "...")
        
        vocabWords = [word1, word2, word3]
    }
    
    var vocabWords: [VocabularyWord] = []
    
}
